export const show = element => {
  element.classList.remove("hide");
};
