export const toggleVisibility = element => {
  element.classList.toggle("hide");
};
