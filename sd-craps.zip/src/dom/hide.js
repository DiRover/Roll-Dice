export const hide = element => {
  element.classList.add("hide");
};
