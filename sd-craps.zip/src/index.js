import { toggleVisibility } from "./dom/toggleVisibility";
import { hide } from "./dom/hide";
import { show } from "./dom/show";

import game from "./game";

import { getAuthor } from "./utils/getAuthor";
import rollDice from "./game/rollDice";

const rollElement = document.getElementById("roll");
const firstDiceElement = document.getElementById("first-dice");
const secondDiceElement = document.getElementById("second-dice");
const disabledRollElement = document.getElementById("disabled-roll");

const winElement = document.getElementById("win");
const failElement = document.getElementById("fail");
const pointElement = document.getElementById("point");

const authorElement = document.getElementById("author");
const yearElement = document.getElementById("year");
const firstRoll = document.getElementById("first-hw");

let numberDice = rollDice();

firstRoll.textContent = "Выпало " + numberDice;
if (numberDice !== 0) show(firstRoll);

rollElement.addEventListener("click", () => {
  hide(firstRoll);
  const results = game();

  firstDiceElement.textContent = results.first;
  secondDiceElement.textContent = results.second;

  if (results.win !== 0) {
    toggleVisibility(disabledRollElement);
    toggleVisibility(rollElement);
  }

  if (results.win === -1) {
    hide(pointElement);
    hide(winElement);
    show(failElement);
    return;
  }

  if (results.win === 0) {
    hide(failElement);
    hide(winElement);
    show(pointElement);
    return;
  }

  if (results.win === 1) {
    show(winElement);
    hide(failElement);
    hide(pointElement);
    return;
  }
});

disabledRollElement.addEventListener("click", () => {
  hide(failElement);
  hide(winElement);
  toggleVisibility(disabledRollElement);
  toggleVisibility(rollElement);
  firstDiceElement.textContent = 1;
  secondDiceElement.textContent = 1;
});

const author = getAuthor();

document.title = `Craps — ${author.name}`;

authorElement.textContent = author.name;
authorElement.href = author.link;
yearElement.textContent = author.year;
