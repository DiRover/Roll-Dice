export const getAuthor = () => {
  const name = "Студент";
  const year = 2154;
  const link = "https://netology.ru/";

  return { name, year, link };
};
