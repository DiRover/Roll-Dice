import rollDice from "./rollDice";

function playGame() {
  let firstResult = rollDice();

  let secondResult = rollDice();

  return [firstResult, secondResult];
}

export default playGame;
