function checkResult(firstResult, secondResult) {
  // Выполняйте домашнее задание здесь
  let sum = firstResult + secondResult;

  if (sum == 7 || sum == 11) {
    return 1;
  } else if (sum == 2 || sum == 3 || sum == 12) {
    return -1;
  } else return 0;
}

export default checkResult;
