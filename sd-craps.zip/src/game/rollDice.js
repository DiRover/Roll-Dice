function rollDice() {
  let choice = Math.random();

  let expandedSection = choice * 6;
  let roundedInteger = Math.floor(expandedSection);
  return 1 + roundedInteger;
}

export default rollDice;
