import playGame from "./playGame";
import checkResult from "./checkResult";

function game() {
  const [first, second] = playGame();
  const win = checkResult(first, second);

  return {
    first,
    second,
    win
  };
}

export default game;
